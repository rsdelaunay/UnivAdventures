<?php
    // Credenciais da Base de dados no Server TGPSI
	define("DB_HOST", "localhost");
    define("DB_USER", "root");
	define("DB_PASSWORD", "");
    define("DB_DATABASE", "VINISYS");
	define("DB_PORT", "3306");
		
	// abertura da ligação (Sintaxe MSQLi)
    // $connect = mysqli_connect(DB1_HOST, DB1_USER, DB1_PASSWORD, DB1_DATABASE, DB1_PORT);

	$connect = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE, DB_PORT);

    // Define a codificação internacional Unicode.
    $connect->set_charset("utf8mb4");
	if (!$connect) {						// Faz a ligação ou devolve o erro ao Mobile
		die("CONNECTION FAIL: ".$connect->connect_error);
	}
		
	// O encerramento da ligação é feita nos scripts de DML
 ?>