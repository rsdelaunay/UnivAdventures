<?php // Executa o get(id) do Aluno na BD
	
	// Abre a lisgação
	require_once('../dbConnect.php');

	// Obtém oo id do url enviado pela app Android
	$id = $_GET['VINHO_ID'];
	
	// Prepara e executa a query para recolha de um registo da tabela Aluno
	$sql = "SELECT * FROM Vinho WHERE VINHO_ID = $id;";
	$dbmsResponse = mysqli_query($connect,$sql);
	
	///////////////////////////////////////////////////////////////////////////////////
	// Preparação do registo para devolver ao Android
	// Transferência do registo para um array, que será convertido para JSON
	///////////////////////////////////////////////////////////////////////////////////

	// Array result para receber o registo
	$result = array();

	// Row recebe o registo da base de dados
	$row = mysqli_fetch_array($dbmsResponse);	
	
	// Grava o registo no array result
	array_push($result,array(
        "ID"=>$row['VINHO_ID'],
        "PRODUTOR_ID"=>$row['PRODUTOR_ID'],
        "REGIAO_ID"=>$row['REGIAO_ID'],
        "Nome"=>$row['nome'],
        "DataEngarrafamento"=>$row['data_engarraf'],
        "TeorAlcoolico"=>$row['teor_alcoolico'],
        "Tipo"=>$row['tipo'],
        "Classificacao"=>$row['classificacao'],
        "Aroma"=>$row['aroma'],
        "Sabor"=>$row['sabor'],
        "Cor"=>$row['cor'],
        "Stock"=>$row['stock'],
	));												// NOTA: Atributos são case sensitive. 
			
	// Codifica o array no formato JSON e devolve-a (echo) ao Android. 
	// No Android, o array result é extraído, seguido do seu conteúdo. 
	// O nome do array é muito importante.
	echo json_encode(array('result'=>$result));
	
	// fecha a ligação
	mysqli_close($connect);
?>