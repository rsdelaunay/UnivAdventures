<?php // Executa o Delete do Aluno na BD

	//Executa a ligação
	require_once('../dbConnect.php');

	// Obtém o id a partir do keyValuepair do url, enviado pela app Mobile
	$id = $_GET['ID'];

	//Query a executar com os dados recebidos do Mobile
	$sql = "DELETE FROM Cliente WHERE numero_cliente=$id;";

	// Executa a query no DBMS e devolve o resultado ao Mobile
	if(mysqli_query($connect,$sql)){
		echo "Sucesso: Registo Eliminado!";
	}else{
		echo "Registo ".$id." Não Eliminado.\nÉ referenciado noutra tabela. \n\nERRO MySQL: ".mysqli_error($connect);
	}

	// Fecha ligação
	mysqli_close($connect);
?>"