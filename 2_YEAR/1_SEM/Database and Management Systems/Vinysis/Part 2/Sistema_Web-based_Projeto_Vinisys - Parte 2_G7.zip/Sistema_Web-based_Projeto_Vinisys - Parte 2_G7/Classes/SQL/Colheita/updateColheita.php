<?php // Executa o Update do Aluno na BD

	// Extrai o método de comunicação. 
	// É apenas mais um keyValuePair que vem na comunicação e que nos permite
	// destinguir o que fazer a seguir.
	if($_SERVER['REQUEST_METHOD'] === 'POST'){
		
		// Abre a ligação
		require_once('../dbConnect.php');

		// Extrai os dados, a partir de 4 keyValuePairs do url
		$id = $_POST['ID'];
		$Quantidade = $_POST['Quantidade'];
		$DataFimColheita = $_POST['DataFimColheita'];
        $DataFimColheita = date("Y-m-d", strtotime($DataFimColheita));	// dateTime para mySQL tem que ser formatada
		
		// Construção da DML Update com os dados recebidos do Android
		$sql = "UPDATE Colheita SET quantidade = '$Quantidade', data_fim = '$DataFimColheita' WHERE COLHEITA_ID = '$id';";

		// Executa a query no DBMS e devolve para o Android a string com o resultado da operação
		if(mysqli_query($connect,$sql)){
			echo "Registo  alterado com sucesso!";
		}else{
			echo "Registo: ".$id." Não alterado!.\n Verifique os dados: \n quantidade: ".$Quantidade."\n data_fim: ".$DataFimColheita;
        }
		
		//fecha ligação
		mysqli_close($connect);
	}
?>