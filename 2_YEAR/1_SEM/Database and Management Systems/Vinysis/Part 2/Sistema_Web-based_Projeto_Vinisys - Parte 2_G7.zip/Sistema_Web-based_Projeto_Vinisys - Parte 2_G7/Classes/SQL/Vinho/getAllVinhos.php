<?php // obtem todos os registos da tabela Aluno da BD para a ListView do Mobile
	
	// Abre a Ligação 
	require_once('../dbConnect.php');

	// Prepara e executa a query para recolha de todos os registos da tabela Aluno
	$sql = "SELECT *, (Select denominacao From Regiao Where REGIAO_ID = Vinho.REGIAO_ID) AS Denominacao, (Select nome_vinicola From Produtor Where PRODUTOR_ID = Vinho.PRODUTOR_ID) AS NomeProdutor FROM Vinho;";
	$dbmsResponse = mysqli_query($connect,$sql);	//Executa a query e guarda o resultado.
	
	///////////////////////////////////////////////////////////////////////////////////
	// Preparação dos registos para devolver ao Mobile
	// Transferência dos registos para o array, que será convertido para JSON
	///////////////////////////////////////////////////////////////////////////////////
	
	// Array result para receber os registos 
	$result = array();

	// Preenchimento dos array com arrays de keyValuPairs dos dados pretendidos
	while($row = mysqli_fetch_array($dbmsResponse)){	
		array_push($result,array(
			"ID"=>$row['VINHO_ID'],
			"PRODUTOR_ID"=>$row['PRODUTOR_ID'],
			"NomeProdutor"=>$row['NomeProdutor'],
			"REGIAO_ID"=>$row['REGIAO_ID'],
			"Denominacao"=>$row['Denominacao'],
			"Nome"=>$row['nome'],
			"DataEngarrafamento"=>$row['data_engarraf'],
			"TeorAlcoolico"=>$row['teor_alcoolico'],
			"Tipo"=>$row['tipo'],
			"Classificacao"=>$row['classificacao'],
			"Aroma"=>$row['aroma'],
			"Sabor"=>$row['sabor'],
			"Cor"=>$row['cor'],
			"Stock"=>$row['stock'],
		));
		// NOTA: Atributos são case sensitive. 
	}

	//Codifica o array no formato JSON e devolve-a (echo) ao Android. 
	// No Android, o array result é extraído, seguido do seu conteúdo. O nome do array é muito importante.
	echo json_encode(array('result'=>$result));
	
	// fecha a ligação
	mysqli_close($connect);
?>	