<?php // Executa o Insert do Aluno na BD

	// Extrai o método de comunicação. 
	// É apenas mais um keyValuePair que vem na comunicação e que nos permite
	// destinguir o que fazer a seguir.
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		// Abre a ligação
		require_once('../dbConnect.php');

		// Este script deve receber um url com 3 keyValuePair, a partir do método
		$AnoColheita = $_POST['AnoColheita'];
		$DataInicioColheita = $_POST['DataInicioColheita'];
		$DataInicioColheita = date("Y-m-d", strtotime($DataInicioColheita));	// dateTime para mySQL tem que ser formatada
		$RegiaoID = $_POST['RegiaoID'];
		$ProdutorID = $_POST['ProdutorID'];
		
		// Construção da DML Insert com os dados recebidos do AndroidW
		$sql = "Insert INTO Colheita (ano, data_inicio, REGIAO_ID, PRODUTOR_ID) 
                    Values ('$AnoColheita','$DataInicioColheita','$RegiaoID', '$ProdutorID')";

		// Executa a query no DBMS e devolve para o Android a string com o resultado da operação
		if(mysqli_query($connect,$sql)){
			echo "Registo Inserido com Sucesso";
		}
		else{
			echo "Registo não inserido. Verifique o código!";
		}
		
		//Fecha a ligação 
		mysqli_close($connect);
	}
?>

