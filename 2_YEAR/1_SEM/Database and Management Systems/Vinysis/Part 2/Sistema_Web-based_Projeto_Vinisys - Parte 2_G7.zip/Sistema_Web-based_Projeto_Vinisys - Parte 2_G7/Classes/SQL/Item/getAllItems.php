<?php // obtem todos os registos da tabela Aluno da BD para a ListView do Mobile
	
	// Abre a Ligação 
	require_once('../dbConnect.php');

	// Prepara e executa a query para recolha de todos os registos da tabela Aluno
		$sql = "SELECT * FROM Item;";
	$dbmsResponse = mysqli_query($connect,$sql);	//Executa a query e guarda o resultado.
	
	///////////////////////////////////////////////////////////////////////////////////
	// Preparação dos registos para devolver ao Mobile
	// Transferência dos registos para o array, que será convertido para JSON
	///////////////////////////////////////////////////////////////////////////////////
	
	// Array result para receber os registos 
	$result = array();

	// Preenchimento dos array com arrays de keyValuPairs dos dados pretendidos
	while($row = mysqli_fetch_array($dbmsResponse)){	
		array_push($result,array(
			"NumFatura"=>$row['FATURA_num_fatura'],
			"VinhoID"=>$row['VINHO_ID'],
			"Quantidade"=>$row['quantidade'],
			"Preco"=>$row['preco'],
			"Dimensao"=>$row['dimensao'],
		));
		// NOTA: Atributos são case sensitive. 
	}

	//Codifica o array no formato JSON e devolve-a (echo) ao Android. 
	// No Android, o array result é extraído, seguido do seu conteúdo. O nome do array é muito importante.
	echo json_encode(array('result'=>$result));
	
	// fecha a ligação
	mysqli_close($connect);
?>	