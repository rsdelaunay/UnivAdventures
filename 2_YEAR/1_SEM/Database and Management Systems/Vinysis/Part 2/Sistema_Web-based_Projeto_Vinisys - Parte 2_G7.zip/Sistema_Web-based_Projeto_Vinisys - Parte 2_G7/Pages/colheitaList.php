<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Global.css">
    <link rel="stylesheet" href="../CSS/Actions.css">
    <script src=" https://kit.fontawesome.com/4dce591932.js " crossorigin="anonymous"></script>
    <title>Listagem</title>
</head>
<body>
<!-- Navegação -->
<div class="navbar">
    <nav class=" flex ">
        <h1 class="brand">Projeto – Parte 2<i class="fas fa-book"></i></h1>
    </nav>
</div>

<!-- container geral -->
<div class="container">

    <!--Titulo da página  -->
    <div class="container-header">
        <h1 class=" title-list text-white text-center ">Consultar Colheitas</h1>
    </div>

    <!-- tabela de alunos -->
    <table class="table" >

        <!-- cabeçalho da tabela onde contém as colunas -->
        <thead class="table-head">
        <tr>
            <th>Ano da Colheita</th>
            <th>Região</th>
            <th>Produtor</th>
            <th>Data Inicio Colheita</th>
            <th>Data Fim Colheita</th>
            <th>Quantidade Colhida</th>
        </tr>
        </thead>

        <!-- Tbody vai conter todas as rows inseridas
            por JS através da function addStudentToTable, que está em: alunoList.js, disparada pelo menu-->
        <tbody id="colheitaList">
        </tbody>
    </table>

    <!-- Rodapé da tabela -->
    <div class="container-footer">
        <input class="btn btn-reset" onclick="location.href='../index.php'" type="reset" value="Cancelar">
        <!-- <input id="btnAdd" class="btn btn-submit" type="button" value="Add"> -->
    </div>
</div>

<!-- Modal Para ações -->
<div id="modal" class="modal">
    <!-- cabeçalho da modal -->
    <div class="actions-modal-header">
        <span class="close">&times;</span>
        <span class="form-edit"> Opções</span>
    </div>

    <!-- conteúdo principal da modal -->
    <div class="modal-content">
        <p>Escolha uma das opções seguintes </p>
        <div class="btn-group">
            <button class="btn btn-submit edit" >Editar</button>
        </div>
    </div>
</div>

<!-- Modal para edit -->
<div id="formModal" class="modal-list">
    <!-- Cabeçalho da modal -->
    <div class="modal-header-list">
        <span class="close">&times;</span>
        <span class="title-modal"> Editar Colheita</span>
    </div>

    <!-- conteúdo principal da modal -->
    <div class="modal-content-list">
        <form id="formColheita" class="formModal">
            <div class="form-group" >
                <label for="anoColheita">Ano da colheita</label>
                <input type="number" name="AnoColheita" id="anoColheita">
            </div>

            <div class="form-group" >
                <label for="dataInicioColheita">Data de inicio da colheita</label>
                <input type="date" name="DataInicioColheita" id="dataInicioColheita">
            </div>
            <br>

            <div class="form-group" >
                <label for="regiao">Região</label>
                <select name="Regiao" id="regiao">
                </select>
            </div>

            <div class="form-group" >
                <label for="produtor">Produtor</label>
                <select name="Produtor" id="produtor">
                </select>
            </div>

            <br>

            <div class="form-group">
                <label class="formModal" for="quantidadeColhida">Quantidade Colhida</label>
                <input type="number" name="QuantidadeColhida" id="quantidadeColhida">
            </div>

            <div class="form-group">
                <label for="dataFimColheita">Data de fim da colheita</label>
                <input type="date" name="DataFimColheita" id="dataFimColheita">
            </div>

            <!--Botões de reset e submit  -->
            <div class="btn-group">
                <input id="btnAction" class="btn btn-submit" type="submit" value="Submeter">
                <input class="btn btn-reset resetForm" type="reset" value="Cancelar">
            </div>
        </form>
    </div>
</div>
<script src="../JS/ColheitaList.js"></script>
</body>
</html>