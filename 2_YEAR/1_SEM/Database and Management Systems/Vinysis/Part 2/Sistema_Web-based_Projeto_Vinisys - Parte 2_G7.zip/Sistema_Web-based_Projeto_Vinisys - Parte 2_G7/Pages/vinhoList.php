<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Global.css">
    <link rel="stylesheet" href="../CSS/Actions.css">
    <script src=" https://kit.fontawesome.com/4dce591932.js " crossorigin="anonymous"></script>
    <title>Listagem</title>
</head>
<body>
<!-- Navegação -->
<div class="navbar">
    <nav class=" flex ">
        <h1 class="brand">Projeto – Parte 2<i class="fas fa-book"></i></h1>
    </nav>
</div>

<!-- container geral -->
<div class="container">

    <!--Titulo da página  -->
    <div class="container-header">
        <h1 class=" title-list text-white text-center ">Consultar Vinhos</h1>

        <div class="form-group" >
            <label for="filterSelect" style="color: #047aed">Filtro</label>
            <select onchange="checkRegiao(event)" name="filterSelect" id="filterSelect">
                <option value="ID">ID</option>
                <option value="Regiao">Região</option>
                <option value="Tipo">Tipo</option>
                <option value="Cor">Cor</option>
                <option value="Aroma">Aroma</option>
                <option value="Sabor">Sabor</option>
            </select>
        </div>

        <div id="inputDiv" class="form-group" >
            <input type="text" name="filterInput"  id="filterInput">
        </div>

        <div id="regiaoDiv" class="form-group" style="display: none;" >
            <select name="Regiao" id="regiao">
            </select>
        </div>

        <button class="btn btn-submit add" >Adicionar</button>

        <div class="form-group" >
            <label for="logicSelect" style="color: #047aed">Operador</label>
            <select name="logicSelect" id="logicSelect">
                <option value="AND">AND</option>
                <option value="OR">OR</option>
            </select>
        </div>

        <button class="btn btn-danger clear">Limpar Filtros</button>
        <button class="btn btn-search search" >Pesquisar</button>

        <div class="form-group" >
            <label id="filterCount">Filtros: </label>
        </div>
        <br>
    </div>

    <!-- tabela de alunos -->
    <table class="table" >

        <!-- cabeçalho da tabela onde contém as colunas -->
        <thead class="table-head">
        <tr>
            <th>Nome</th>
            <th>Tipo</th>
            <th>Região</th>
        </tr>
        </thead>

        <!-- Tbody vai conter todas as rows inseridas
            por JS através da function addStudentToTable, que está em: alunoList.js, disparada pelo menu-->
        <tbody id="vinhoList">
        </tbody>
    </table>

    <!-- Rodapé da tabela -->
    <div class="container-footer">
        <input class="btn btn-reset" onclick="location.href='../index.php'" type="reset" value="Cancelar">
        <!-- <input id="btnAdd" class="btn btn-submit" type="button" value="Add"> -->
    </div>
</div>

<!-- Modal Para ações -->
<div id="modal" class="modal">
    <!-- cabeçalho da modal -->
    <div class="actions-modal-header">
        <span class="close">&times;</span>
        <span class="form-edit"> Opções</span>
    </div>

    <!-- conteúdo principal da modal -->
    <div class="modal-content">
        <p>Escolha uma das opções seguintes </p>
        <div class="btn-group">
            <button onclick="location.href='vinhoDetail.php'" class="btn btn-search view" >Detalhes</button>
        </div>
    </div>
</div>
<script src="../JS/VinhoList.js"></script>

<!-- código local Js -->
<script>
    /*Faz a modal fechar com clique no X*/
    document.querySelector('.close').addEventListener('click', ()=> {
        document.querySelector('.modal').style.display = 'none';
    });
</script>
</body>
</html>