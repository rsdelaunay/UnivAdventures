<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Global.css">
    <link rel="stylesheet" href="../CSS/Actions.css">
    <script src=" https://kit.fontawesome.com/4dce591932.js " crossorigin="anonymous"></script>
    <title>Listagem</title>
</head>
<body>
<!-- Navegação -->
<div class="navbar">
    <nav class=" flex ">
        <h1 class="brand">Projeto – Parte 2<i class="fas fa-book"></i></h1>
    </nav>
</div>

<!-- container geral -->
<div class="container">

    <!--Titulo da página  -->
    <div class="container-header">
        <h1 class=" title-list text-white text-center ">Vinho</h1>

        <form id="formColheita" class="formModal">
            <div class="form-group" >
                <label for="nome">Nome</label>
                <input disabled type="text" name="nome" id="nome">
            </div>

            <div class="form-group" >
                <label for="dataEngarrafamento">Data de Engarrafamento</label>
                <input disabled type="date" name="dataEngarrafamento" id="dataEngarrafamento">
            </div>

            <div class="form-group" >
                <label for="teorAlcoolico">Teor Aloólico</label>
                <input disabled type="text" name="teorAlcoolico" id="teorAlcoolico">
            </div>

            <div class="form-group" >
                <label for="tipo">Tipo</label>
                <input disabled type="text" name="tipo" id="tipo">
            </div>

            <div class="form-group" >
                <label for="cor">Cor</label>
                <input disabled type="text" name="cor" id="cor">
            </div>

            <div class="form-group" >
                <label for="aroma">Aroma</label>
                <input disabled type="text" name="aroma" id="aroma">
            </div>

            <div class="form-group" >
                <label for="sabor">Sabor</label>
                <input disabled type="text" name="sabor" id="sabor">
            </div>

            <div class="form-group" >
                <label for="regiao">Região</label>
                <input disabled type="text" name="regiao" id="regiao">
            </div>

            <br>

            <h1 class=" title-list text-white text-center ">Produtor</h1>

            <div class="form-group" >
                <label for="nomeVinicola">Nome Vinicola</label>
                <input disabled type="text" name="nomeVinicola" id="nomeVinicola">
            </div>

            <div class="form-group" >
                <label for="email">Email</label>
                <input disabled type="text" name="email" id="email">
            </div>

            <div class="form-group" >
                <label for="morada">Morada</label>
                <input disabled type="text" name="morada" id="morada">
            </div>

            <div class="form-group" >
                <label for="codigoPostal">Codigo Postal</label>
                <input disabled type="text" name="codigoPostal" id="codigoPostal">
            </div>

            <div class="form-group" >
                <label for="telefone">Telefone</label>
                <input disabled type="text" name="telefone" id="telefone">
            </div>

            <br>

            <h1 class=" title-list text-white text-center ">Prémios</h1>

            <!-- tabela de premios -->
            <table class="table" >

                <!-- cabeçalho da tabela onde contém as colunas -->
                <thead class="table-head">
                <tr>
                    <th>Nome Distinção</th>
                    <th>Entidade</th>
                </tr>
                </thead>

                <!-- Tbody vai conter todas as rows inseridas
                    por JS através da function addStudentToTable, que está em: alunoList.js, disparada pelo menu-->
                <tbody id="premiosGanhosList">
                </tbody>
            </table>

            <!--Botões de reset e submit  -->
            <div class="btn-group">
                <input class="btn btn-reset" onclick="location.href='../index.php'" type="reset" value="Cancelar">
            </div>
        </form>

        <br>
    </div>
</div>
<script src="../JS/VinhoDetail.js"></script>
</body>
</html>