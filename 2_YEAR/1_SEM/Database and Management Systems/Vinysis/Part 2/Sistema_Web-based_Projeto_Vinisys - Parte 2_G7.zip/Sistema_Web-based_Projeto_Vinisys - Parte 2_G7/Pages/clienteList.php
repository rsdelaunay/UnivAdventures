<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Global.css">
    <link rel="stylesheet" href="../CSS/Actions.css">
    <script src=" https://kit.fontawesome.com/4dce591932.js " crossorigin="anonymous"></script>
    <title>Listagem</title>
</head>
<body>
<!-- Navegação -->
<div class="navbar">
    <nav class=" flex ">
        <h1 class="brand">Projeto – Parte 2<i class="fas fa-book"></i></h1>
    </nav>
</div>

<!-- container geral -->
<div class="container">

    <!--Titulo da página  -->
    <div class="container-header">
        <h1 class=" title-list text-white text-center ">Consultar Clientes</h1>
        <br>
    </div>

    <!-- tabela de alunos -->
    <table class="table" >

        <!-- cabeçalho da tabela onde contém as colunas -->
        <thead class="table-head">
        <tr>
            <th>Nome</th>
            <th>Tipo</th>
            <th>NIF</th>
            <th>Morada</th>
            <th>Quantidade de vinhos comprados</th>
            <th>Valor Gasto</th>
            <th></th>
        </tr>
        </thead>

        <!-- Tbody vai conter todas as rows inseridas
            por JS através da function addStudentToTable, que está em: alunoList.js, disparada pelo menu-->
        <tbody id="clienteList">
        </tbody>
    </table>

    <!-- Rodapé da tabela -->
    <div class="container-footer">
        <input class="btn btn-reset" onclick="location.href='../index.php'" type="reset" value="Cancelar">
        <!-- <input id="btnAdd" class="btn btn-submit" type="button" value="Add"> -->
    </div>
</div>
<script src="../JS/ClienteList.js"></script>
</body>
</html>