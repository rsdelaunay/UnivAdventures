<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/Global.css">
    <link rel="stylesheet" href="CSS/Actions.css">
    <script src=" https://kit.fontawesome.com/4dce591932.js" crossorigin="anonymous"></script>
    <title>Pagina inicial</title>
</head>
<body>

<!-- Menu para navegar entre a lista e para abrir o formulário-->
<div class="navbar">
    <nav class="flex">
        <h1 class="brand">Projeto – Parte 2<i class="fas fa-book"></i></h1>
        <div class="dropdown">Colheitas
            <div class="dropdown-content">
                <div class="dropdown-item">
                    <a class="insert" onclick="showModal()">Inserir <i class="fas fa-user-plus"></i></a>
                </div>
                <div>
                    <a href="Pages/colheitaList.php">Consultar &nbsp;&nbsp; <i class="fas fa-bars"></i></a>
                </div>
            </div>
        </div>
        <div class="dropdown">Vinhos
            <div class="dropdown-content">
                <div>
                    <a href="Pages/vinhoList.php">Consultar &nbsp;&nbsp; <i class="fas fa-bars"></i></a>
                </div>
            </div>
        </div>
        <div class="dropdown">Clientes
            <div class="dropdown-content">
                <div>
                    <a href="Pages/clienteList.php">Consultar &nbsp;&nbsp; <i class="fas fa-bars"></i></a>
                </div>
            </div>
        </div>
    </nav>
</div>

<!-- Titulo -->
<h1 class="main-title">Projeto de Bases de Dados</h1>
<h1 class="main-title">“VINISYS” - PARTE-II</h1>
<h1 class="sub-title">Grupo 7:</h1>
<div style="margin: auto;width: 30%;">
    <ul style="color: white;">
        <li><h1 class="names">Francisco Martins Ribeiro – Aluno N.º 123930</h1></li>
        <li><h1 class="names">Pedro Miguel Pereira Clemente – Aluno N.º 110337</h1></li>
        <li><h1 class="names">Rodrigo Miguel da Silva Delaunay - Aluno N.º 122123</h1></li>
        <li><h1 class="names">Rúben Manuel Henriques Rocha – Aluno N.º 66174</h1></li>
    </ul>
</div>

<!-- Modal para edit -->
<div id="formModal" class="modal-edit">

    <!-- cabeçalho -->
    <div class="modal-header-edit">
        <span class="close">&times;</span>
        <span class="title-modal"> Inserir Colheita</span>
    </div>

    <!-- Modal content -->
    <div class="modal-content-edit">
        <form id="formColheita" class="formModal">
            <div class="form-group" >
                <label for="anoColheita">Ano da colheita</label>
                <input type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="4" name="AnoColheita" id="anoColheita">
            </div>

            <div class="form-group" >
                <label for="dataInicioColheita">Data de inicio da colheita</label>
                <input type="date" name="DataInicioColheita" id="dataInicioColheita">
            </div>
            <br>

            <div class="form-group" >
                <label for="regiao">Região</label>
                <select name="Regiao" id="regiao">
                </select>
            </div>

            <div class="form-group" >
                <label for="produtor">Produtor</label>
                <select name="Produtor" id="produtor">
                </select>
            </div>

            <!--Botões de reset e submit  -->
            <div class="btn-group">
                <input id="btnAction" class="btn btn-submit" type="submit" value="Submeter">
                <input class="btn btn-reset resetForm" type="reset" value="Cancelar">
            </div>
        </form>
    </div>
</div>

<!-- referência para o ficheiro JS externo do AlunoEdit-->
<script src="JS/ColheitaEdit.js"></script>

<!-- código local Js -->
<script>

    //ação de click no botão
    document.querySelector('.insert').addEventListener('click',() => {
        localStorage.setItem('action', "INSERT");
    });

    /**
     *
     *Mostra a modal na página inicial sobre app demo
     */
    function showModal() {
        document.querySelector('.modal-edit').style.display = 'block';
        document.querySelector('.title-modal').innerText = 'Inserir Colheita';
    }

    /*Faz a modal fechar com clique no X*/
    document.querySelector('.close').addEventListener('click', ()=> {
        document.querySelector('.modal-edit').style.display = 'none';
    });

    /*Faz a modal fechar com clique no botão de cancelar*/
    document.querySelector('.btn-reset').addEventListener('click', ()=> {
        document.querySelector('.modal-edit').style.display = 'none';
    });
</script>


</body>
</html>