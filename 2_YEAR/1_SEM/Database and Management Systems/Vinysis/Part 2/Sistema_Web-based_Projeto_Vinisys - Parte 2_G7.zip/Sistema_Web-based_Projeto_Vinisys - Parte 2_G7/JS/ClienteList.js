let filtersMap = new Map();
let filterCount = 0;
/**
 * This class will handle all actions
 * about graphic actions
 */
class UI {

    /**
     * Get all clientes from local storage (future)
     */
    static getAll() {
        //obtém da base de dados e cria os registos na tabela
        BD.getAllFaturasFromDataBase();
        BD.getALLItemsFromDatabase();
        BD.getAllClientesFromDataBase();
    }
    /**
     * function to add graphically each object
     * @param {cliente} cliente
     */
    static addClienteToTable(cliente) {
        let faturasMap = Store.getAllClienteFaturasFromLocalStorage(cliente.ID);
        let totalGasto = faturasMap.get(0);
        let faturasList = faturasMap.get(1);
        let totalVinhos = Store.getTotalVinhosCompradosFromLocalStorage(faturasList);

        //obtém o tbody da tabela do cliente através do ID
        let list = document.querySelector('#clienteList');

        //create element - Função que permite criar uma instância do elemento
        //passado no parâmetro de entrada
        const row = document.createElement('tr');

        //construção da lista dentro da tag tbody
        row.innerHTML = `
            <td>${cliente.NomeCliente}</td>            
            <td>${cliente.Tipo}</td>
            <td>${cliente.Nif}</td>
            <td>${cliente.Morada}</td>            
            <td>${totalVinhos}</td>
            <td>${totalGasto}</td>
        `;

        if(totalGasto === 0) {
            row.innerHTML += '<td class="deleteCliente" style="color: red;cursor: pointer;">&times;</td>';
        }

        //adiciona o elemento filho ao elemento pai que
        //foi criado anteriormente (tr)
        list.appendChild(row);
    }

    /**
     * Irá definir se o utilizador quer editar ou eliminar
     * @param {element} element
     */
    static clickForAction(element) {

        //obtém o valor da lista
        let rowIndex = element.parentElement.rowIndex;

        //caso não tenha id na local storage iremos criar
        if(typeof localStorage.getItem('userSelectedId') === 'undefined' || localStorage.getItem('userSelectedId') === null) {
            //cria na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
        } else {

            //altera na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
            // //erro o utilizador
            // confirm("Erro: Não foi possível encontrar o registo selecionado. Contacte o programador");
        }

        //lista de clientes temporária
        let clientes = Store.getAllFromLocalStorage()

        //percorre o indice da nossa lista de cliente
        for(let cliente in clientes) {

            //valida se o index é o mesmo
            if(parseInt(cliente) === rowIndex -1) {
                //salva o id na localstorage
                Store.updateFlag('userSelectedId', clientes[cliente].ID);
                Store.updateFlag('action', 'DELETE');

                //obtem o id do registo ativo
                let clienteToDelete = localStorage.getItem('userSelectedId');
                Store.deleteOnStorage(clienteToDelete);

                //refresh da tabela
                UI.refreshTable();
            }
        }
    }


    /**
     * remove an element from html
     * @param {el} el
     */
    static removeAllTableRows(el) {
        //limpa o conteúdo dentro da tag tbody
        document.querySelector('#clienteList').innerHTML = "";
    }

    /**
     * Resfresh da tabela
     */
    static refreshTable() {

        //remove todos os filhos da tabela
        UI.removeAllTableRows();

        //obtém o array da local storage atualizado
        const clientes = Store.getAllFromLocalStorage();

        //passa 1 objeto de cada vez para reconstruir a tabela
        clientes.forEach(cliente => {
            UI.addClienteToTable(cliente);
        })
    }
}

/**
 * Classe que irá interagir com a local storage
 */
class Store {
    static deleteOnStorage(clienteID) {
        let clientes  = Store.getAllFromLocalStorage();

        //percorre a lista e remove o registo
        clientes.forEach( async (cliente, index) => {
            if(parseInt(cliente.ID) === parseInt(clienteID) ) {

                //remove 1 registo da lista
                clientes.splice(index, 1);

                //remove na bd
                await BD.deleteOnDataBase(cliente.ID);
            }
        });

        //atualiza a localstorage
        localStorage.setItem('clientes', JSON.stringify(clientes));
    }

    /**
     * Busca todos os registos da local storage
     */
    static getAllFromLocalStorage() {
        //variável da lista
        let listClientes = [];

        //valida se tem registos na localStorage
        if(localStorage.getItem('clientes') != null) {
            //caso tenha registos obtém a lista e converte para o formato JSON
            listClientes = JSON.parse(localStorage.getItem('clientes'));
        }

        //retorna a lista
        return listClientes;
    }

    /**
     * Busca todos os registos da local storage
     */
    static getAllClienteFaturasFromLocalStorage(numeroCliente) {
        let NumeroCliente = numeroCliente;

        //variável da lista
        let faturasList = JSON.parse(localStorage.getItem('faturas')).filter((element) => element.NumeroCliente === NumeroCliente);

        let faturasMap = new Map();

        let totalGasto = 0;

        //valida se tem registos na localStorage
        if(localStorage.getItem('faturas') != null) {
            faturasList.forEach(element => {
                if(element.NumeroCliente === numeroCliente) {
                    totalGasto += parseFloat(element.ValorTotal);
                }
            })
        }

        faturasMap.set(0, totalGasto);
        faturasMap.set(1, faturasList);

        //retorna a lista
        return faturasMap;
    }

    /**
     * Busca todos os registos da local storage
     */
    static getTotalVinhosCompradosFromLocalStorage(faturasList) {
        //variável da lista
        let totalVinhosComprados = 0;

        //valida se tem registos na localStorage
        if(localStorage.getItem('items') != null) {
            JSON.parse(localStorage.getItem('items')).forEach(element => {
                faturasList.forEach(fatura => {
                    if(element.NumFatura === fatura.ID) {
                        totalVinhosComprados += parseInt(element.Quantidade);
                    }
                })
            })
        }

        //retorna a lista
        return totalVinhosComprados;
    }

    /**
     * Função que  adiciona ou edita valores
     * de uma flag na localstorage
     * @param {flag desejada} flag
     * @param {valor da flag} value
     */
    static updateFlag(flag, value) {
        return localStorage.setItem(flag, value);   //retorna a flag modificada com os valores dos parametros
    }
}

class BD {
    static async deleteOnDataBase(id) {
        //endpoint desejado para efetuar ação de delete
        let url = '../Classes/SQL/Cliente/deleteCliente.php';
        let parametros = `ID=${id}`;

        //instancia do XMLHttpRequest para chamada assíncrona
        let request = new XMLHttpRequest();

        //faz chamada para o nosso endpoint de insert
        request.open('GET', url + '?'+ parametros, true);

        //resposta caso tudo esteja ok
        request.onload = await function () {
            alert(` Status: ${request.status} \n
                    Response: ${request.responseText}`);
        }

        //resposta caso dê erro
        request.onerror = await function () {
            alert(` Status: ${ request.status} \n
                    Response: ${request.responseText}`);
        }

        //envia request para remover o registo
        request.send();
    }

    static getAllFaturasFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Fatura/getAllFaturas.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const faturas = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('faturas', JSON.stringify(faturas.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getALLItemsFromDatabase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Item/getAllItems.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const items = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('items', JSON.stringify(items.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllClientesFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Cliente/getAllClientes.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const clientes = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {

                //retorna a lista da base de dados
                clientes.result.forEach((cliente) => {
                    UI.addClienteToTable(cliente);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('clientes', JSON.stringify(clientes.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }
}

///////////////////////////////////////////////////////////////
/// Evento para adicionar quando DOM for carregado
///////////////////////////////////////////////////////////////

document.addEventListener('DOMContentLoaded', UI.getAll);

///////////////////////////////////////////////////////////////
/// Evento para remover quando haver clique do botão
///////////////////////////////////////////////////////////////
/**
 * Click event when click
 */
document.addEventListener("click", function(e){
    const target = e.target.closest(".deleteCliente"); // Or any other selector.

    if(target){
        UI.clickForAction(e.target);
    }
});

/*
document.querySelector('.delete').addEventListener('click', () =>{
});*/

/*---------------------------------MODAL------------------------------------------------*/

// obtém a modal
var modal = document.getElementById("modal");

// quando utilizador clicar qualquer lugar fora da modal, a modal fecha-se
window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
}
//#endregion