/**
 * This class will handle all actions
 * about graphic actions
 */
class UI {

    /**
     * Get all colheitas from local storage (future)
     */
    static getAll() {

        //obtém da base de dados e cria os registos na tabela
        BD.getAllRegioesFromDataBase();
        BD.getAllProdutoresFromDataBase();
        BD.getAllColheitasFromDataBase();
        //#region local array
        // //array of local data

        //#endregion


    }
    /**
     * function to add graphically each object
     * @param {colheita} colheita
     */
    static addColheitaToTable(colheita) {

        //obtém o tbody da tabela do colheita através do ID
        let list = document.querySelector('#colheitaList');

        //create element - Função que permite criar uma instância do elemento
        //passado no parâmetro de entrada
        const row = document.createElement('tr');

        let date = '';
        let quantidade = '';

        if(colheita.DataFimColheita != null) {
            date = new Date(colheita.DataFimColheita).toLocaleDateString()
        }

        if(colheita.Quantidade != null) {
            quantidade = colheita.Quantidade;
        }

        //construção da lista dentro da tag tbody
        row.innerHTML = `
            <td>${colheita.AnoColheita}</td>
            <td>${colheita.Denominacao}</td>
            <td>${colheita.Nome}</td>
            <td>${ new Date(colheita.DataInicioColheita).toLocaleDateString()}</td>
            <td>${ date}</td>
            <td>${quantidade}</td>
        `;

        //adiciona o elemento filho ao elemento pai que
        //foi criado anteriormente (tr)
        list.appendChild(row);
    }

    /**
     * remove an element from html
     * @param {el} el
     */
    static removeAllTableRows(el) {

        //limpa o conteúdo dentro da tag tbody
        document.querySelector('#colheitaList').innerHTML = "";
    }

    /**
     * Irá definir se o utilizador quer editar ou eliminar
     * @param {element} element
     */
    static clickForAction(element) {

        //obtém o valor da lista
        let rowIndex = element.parentElement.rowIndex;

        //caso não tenha id na local storage iremos criar
        if(typeof localStorage.getItem('userSelectedId') === 'undefined' || localStorage.getItem('userSelectedId') === null) {
            //cria na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
        } else {

            //altera na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
            // //erro o utilizador
            // confirm("Erro: Não foi possível encontrar o registo selecionado. Contacte o programador");
        }

        //lista de colheitas temporária
        let colheitas = Store.getAllFromLocalStorage()

        //percorre o indice da nossa lista de colheita
        for(let colheita in colheitas) {

            //valida se o index é o mesmo
            if(parseInt(colheita) === rowIndex -1) {

                //salva o id na localstorage
                Store.updateFlag('userSelectedId', colheitas[colheita].ID);

                if(colheitas[colheita].DataFimColheita === null && colheitas[colheita].Quantidade === null) {
                    //mostra a modal
                    document.getElementById('modal').style.display = "block";
                }
            }
        }
    }

    /**
     * Preeenche o formulário da modal para editar dados
     */
    static fillEditForm() {

        //obtém os elementos html para mudar o texto e estilos
        document.querySelector('.title-modal').textContent = 'Editar colheita';
        document.querySelector('#btnAction').classList.add('btn-submit');
        document.querySelector('#btnAction').classList.remove('btn-danger');
        document.querySelector('#btnAction').textContent = 'Editar';

        //valida se a flag está na local Storage
        if(localStorage.getItem('action') === 'UPDATE') {
            //obtém os elementos do form na modal
            const anoColheita = document.querySelector('#anoColheita');
            const dataInicioColheita = document.querySelector('#dataInicioColheita');
            const dataFimColheita = document.querySelector('#dataFimColheita');
            const quantidadeColhida = document.querySelector('#quantidadeColhida');
            const regiaoDenominacao = document.querySelector('#regiao');
            const produtorNome = document.querySelector('#produtor');

            //mostra a modal do formulário
            document.getElementById('formModal').style.display = "block";

            //obtém o item
            let userIdFromLocalStorage = localStorage.getItem('userSelectedId');
            //lista de colheitas temporária
            let colheitas = Store.getAllFromLocalStorage();

            //percorre o array da local storage
            //vai a procura do valor que temos guardado na key id
            colheitas.forEach((colheita) => {

                //caso encontre o Id do utilizador
                if (parseInt(colheita.ID) === parseInt(userIdFromLocalStorage)) {
                    anoColheita.disabled = true;
                    dataInicioColheita.disabled = true;
                    regiaoDenominacao.disabled = true;
                    produtorNome.disabled = true;

                    //deixa os campos disponíveis para modificar
                    dataFimColheita.disabled = false;
                    quantidadeColhida.disabled = false;

                    //atribuição de valores aos atributos
                    anoColheita.value = colheita.AnoColheita;
                    quantidadeColhida.value = colheita.Quantidade;
                    regiaoDenominacao.value = colheita.RegiaoID;
                    produtorNome.value = colheita.ProdutorID;

                    //faz as devidas conversões para o formato correto que o date picker exige
                    dataInicioColheita.value = new Date(colheita.DataInicioColheita).toISOString().toString().substring(0, 10);

                    if(colheita.DataFimColheita != null) {
                        dataFimColheita.value = new Date(colheita.DataFimColheita).toISOString().toString().substring(0, 10);
                    }
                }
            });
        } else {
            alert('Erro: contacte o programador.');
        }
    }

    /**
     * Limpa todos os campos do formulário
     */
    static resetForm() {

        //limpa os campos do formulário
        document.querySelector('#anoColheita').value = '';
        document.querySelector('#dataInicioColheita').value = '';
        document.querySelector('#regiao').value = '';
        document.querySelector('#produtor').value = '';
        document.querySelector('#quantidadeColhida').value = '';
        document.querySelector('#dataFimColheita').value = '';

        //muda a flag do utilizador selecionado para undefined
        localStorage.setItem('userSelectedId', 'undefined');

        //esconde a modal do formulário
        document.getElementById("formModal").style.display = 'none';

        //esconde a modal das opções de remover ou editar
        document.getElementById("modal").style.display = 'none';
    }

    /**
     * Fecha todas as janelas modais
     */
    static closeModals() {

        //obtém os elementos do html
        const modal = document.getElementById("modal");
        const formModal = document.querySelector("#formModal");

        //esconde as modais
        modal.style.display = "none";

        //esconde a modal das opções de remover ou editar
        formModal.style.display = "none";
    }

    /**
     * Resfresh da tabela
     */
    static refreshTable() {

        //remove todos os filhos da tabela
        UI.removeAllTableRows();

        //obtém o array da local storage atualizado
        const colheitas = Store.getAllFromLocalStorage();

        //passa 1 objeto de cada vez para reconstruir a tabela
        colheitas.forEach(colheita => {
            UI.addColheitaToTable(colheita);
        })
    }
}

/**
 * Classe que irá interagir com a local storage
 */
class Store {

    /**
     * Atualiza um registo da lista
     * @param {colheitaId} colheitaId
     */
    static updateOnStorage(colheitaId) {

        //lista de colheitas temporária
        let colheitas = Store.getAllFromLocalStorage();

        //valores do formulário
        let dataFimColheita = document.querySelector('#dataFimColheita').value;
        let quantidadeColhida = document.querySelector('#quantidadeColhida').value;

        //percorre a lista e muda os valores do array na localStorage
        colheitas.forEach( async(colheita) => {
            //percorre a lista de utilizadores e procura se o id é igual ao do utilizador ativo
            //atualiza o valor do objeto
            if(parseInt(colheita.ID) === parseInt(colheitaId)) {

                //preenche o objeto com novos dados
                colheita.Id = colheitaId;
                colheita.Quantidade = quantidadeColhida;
                colheita.DataFimColheita = dataFimColheita;

                //envia objeto para alterar as informações do registo na base de dados
                await BD.updateOnDataBase(colheita);

            }
        });

        //atualiza a lista na localStorage
        localStorage.setItem('colheitas', JSON.stringify(colheitas));
    }

    /**
     * Busca todos os registos da local storage
     */
    static getAllFromLocalStorage() {
        //variável da lista
        let listColheitas;

        //valida se tem registos na localStorage
        if(localStorage.getItem('colheitas') == null) {

            //caso não tenha registo cria um array vazio
            listColheitas = [];
        } else {

            //caso tenha registos obtém a lista e converte para o formato JSON
            listColheitas = JSON.parse(localStorage.getItem('colheitas'));
        }

        //retorna a lista
        return listColheitas;
    }

    /**
     * Função que  adiciona ou edita valores
     * de uma flag na localstorage
     * @param {flag desejada} flag
     * @param {valor da flag} value
     */
    static updateFlag(flag, value) {
        return localStorage.setItem(flag, value);   //retorna a flag modificada com os valores dos parametros
    }
}

class BD {
    /**
     * Função de alterar um registo na base de dados
     * @param colheita objeto colheita preenchido
     * @return {Promise<void>}
     */
    static async updateOnDataBase(colheita) {

        //criação de parametros para enviar no body
        let parametros = `ID=${colheita.ID}&DataFimColheita=${colheita.DataFimColheita}&Quantidade=${colheita.Quantidade}`;

        //endpoint desejado para efetuar ação de update
        let url = '../Classes/SQL/Colheita/updateColheita.php';

        //instancia do XMLHttpRequest(ajax) para chamada assíncrona
        let request = new XMLHttpRequest();

        //faz chamada para o nosso endpoint de update
        request.open('POST', url, true);

        // Envia a informação do cabeçalho junto com a requisição.
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        //resposta caso tudo esteja ok
        request.onload = await function () {
            alert(` Status: ${request.status} \n
                    Response: ${request.responseText}`);
        }

        //resposta caso dê erro
        request.onerror = await function () {
            alert(` Status: ${ request.status} \n
                    Response: ${request.responseText}`);
        }

        //envia com os parametros no body ou seja, encripitado
        request.send(parametros);

        //fecha as modais
        UI.closeModals();
    }

    static getAllRegioesFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Regiao/getAllRegioes.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const regioes = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //obtém o tbody da tabela do colheita através do ID
                let regiaoSelect = document.querySelector('#regiao');

                //retorna a lista da base de dados
                regioes.result.forEach((regiao) => {
                    var opt = document.createElement('option');
                    opt.value = regiao.ID;
                    opt.innerHTML = regiao.Denominacao;
                    regiaoSelect.appendChild(opt);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('regioes', JSON.stringify(regioes.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllProdutoresFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Produtor/getAllProdutores.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const produtores = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //obtém o tbody da tabela do colheita através do ID
                let produtorSelect = document.querySelector('#produtor');

                //retorna a lista da base de dados
                produtores.result.forEach((produtor) => {
                    var opt = document.createElement('option');
                    opt.value = produtor.ID;
                    opt.innerHTML = produtor.NomeVinicola;
                    produtorSelect.appendChild(opt);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('produtores', JSON.stringify(produtores.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllColheitasFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Colheita/getAllColheitas.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const colheitas = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {

                //retorna a lista da base de dados
                colheitas.result.forEach((colheita) => {
                    UI.addColheitaToTable(colheita);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('colheitas', JSON.stringify(colheitas.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }
}

///////////////////////////////////////////////////////////////
/// Evento para adicionar quando DOM for carregado
///////////////////////////////////////////////////////////////

document.addEventListener('DOMContentLoaded', UI.getAll);

///////////////////////////////////////////////////////////////
/// Evento para remover quando haver clique do botão
///////////////////////////////////////////////////////////////
/**
 * Click event when click
 */
document.getElementById('colheitaList').addEventListener('click', function (e) {
    e.preventDefault();
    //removing row element from the table
    UI.clickForAction(e.target);
});


document.querySelector('.edit').addEventListener('click', () =>{
    //define flag de edição
    Store.updateFlag('action', 'UPDATE');

    //call edit
    UI.fillEditForm();
});

/**
 * Botão que irá decidir as ações de:
 * Insert
 * Delete
 * Update
 */
document.querySelector('#formModal').addEventListener('submit', (e) => {

    //impede a página de recarregar
    e.preventDefault();

    //action da local storage
    let action = localStorage.getItem('action');

    //consoante a flag, executa uma determinada ação.
    switch (action) {

        case 'UPDATE':
            Store.updateFlag('action', 'UPDATE');
            if (validate()) {
                //obtém o utilizador ativo para mudar os dados
                let colheitaToUpdate = localStorage.getItem('userSelectedId');

                //atualiza o registo na local storage
                Store.updateOnStorage(colheitaToUpdate);

                //esconde as janelas modais
                UI.closeModals();

                //refresh da tabela
                UI.refreshTable();
            }
            break;

        case 'DELETE':
            Store.updateFlag('action', 'DELETE');

            //obtem o id do registo ativo
            let studentToDelete = localStorage.getItem('userSelectedId');
            Store.deleteOnStorage(studentToDelete);

            //esconde as janelas modais
            UI.closeModals();

            //refresh da tabela
            UI.refreshTable();
            break;
    }

});

/**
 * quando botão de cancelar for clicado limpa todos os dados da form e também da local storage
 */
document.querySelector('.resetForm').addEventListener('click', ()=> {

    //limpa a form e a local storage do utilizador selecionado
    UI.resetForm();
})

/*---------------------------------MODAL------------------------------------------------*/

// obtém a modal
var modal = document.getElementById("modal");
var formModal = document.querySelector("#formModal");

// tem o elemento span X para fechar a modal
var span = document.querySelector(".close");

// quando utilizador fizer o clique no <span> (x), a modal fecha-se
span.onclick = function() {
    UI.closeModals();
}

// quando utilizador clicar qualquer lugar fora da modal, a modal fecha-se
window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
}

//#region validações

/**
 * Função que orá validar se o formulário está a funcionar corretamente
 */
function validate() {
    //Elementos html
    let anoColheita = document.getElementById("anoColheita");
    let dataInicioColheita = document.getElementById("dataInicioColheita");
    let quantidadeColhida = document.getElementById("quantidadeColhida");
    let dataFimColheita = document.getElementById("dataFimColheita");

    if (validateNumbers(anoColheita.value) && !validateEmpty(anoColheita.value) && !validateEmpty(dataInicioColheita.value) && validateNumbers(quantidadeColhida.value) && !validateEmpty(quantidadeColhida.value && !validateEmpty(dataFimColheita.value))){
        return true;
    } else {
        return false;
    }

}

/************************* Regex e metodos de validação ****************************************** */
let regexForNumbers = /^[0-9]+$/;

/**
 * Função que valida apenas os números
 * @param inputText texto do formulário
 * @returns {boolean} true é apenas número /false - não é somente número
 */
function validateNumbers(inputNumbers) {
    //validações para os números
    if (inputNumbers.match( regexForNumbers)) {
        return true
    } else {
        return false
    }
}

/**
 * Função que valida se tá vazio
 * @param inputText texto do formulário
 * @returns {boolean} true - vazio / false - preenchido
 */
function validateEmpty(inputText) {

    //valida se está vazio
    if (inputText.length === 0 || typeof inputText.textContent === undefined) {
        return true;
    }
    return false;
}
//#endregion