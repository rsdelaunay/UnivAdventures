let filtersMap = new Map();
let filterCount = 0;
/**
 * This class will handle all actions
 * about graphic actions
 */
class UI {

    /**
     * Get all vinhos from local storage (future)
     */
    static getAll() {
        document.querySelector('#filterCount').innerHTML = "Filtros: " + filterCount;

        //obtém da base de dados e cria os registos na tabela
        BD.getAllRegioesFromDataBase();
        BD.getALLEdicoesFromDatabase()
        BD.getALLPremiosFromDatabase();
        BD.getALLGanhosFromDatabase();
        BD.getAllVinhosFromDataBase();
    }
    /**
     * function to add graphically each object
     * @param {vinho} vinho
     */
    static addVinhoToTable(vinho) {

        //obtém o tbody da tabela do vinho através do ID
        let list = document.querySelector('#vinhoList');

        //create element - Função que permite criar uma instância do elemento
        //passado no parâmetro de entrada
        const row = document.createElement('tr');

        //construção da lista dentro da tag tbody
        row.innerHTML = `
            <td>${vinho.Nome}</td>            
            <td>${vinho.Tipo}</td>
            <td>${vinho.Denominacao}</td>
        `;

        //adiciona o elemento filho ao elemento pai que
        //foi criado anteriormente (tr)
        list.appendChild(row);
    }

    /**
     * remove an element from html
     * @param {el} el
     */
    static removeAllTableRows(el) {

        //limpa o conteúdo dentro da tag tbody
        document.querySelector('#vinhoList').innerHTML = "";
    }

    /**
     * Irá definir se o utilizador quer editar ou eliminar
     * @param {element} element
     */
    static clickForAction(element) {

        //obtém o valor da lista
        let rowIndex = element.parentElement.rowIndex;

        //caso não tenha id na local storage iremos criar
        if(typeof localStorage.getItem('userSelectedId') === 'undefined' || localStorage.getItem('userSelectedId') === null) {
            //cria na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
        } else {

            //altera na localstorage
            Store.updateFlag('userSelectedId', rowIndex);
            // //erro o utilizador
            // confirm("Erro: Não foi possível encontrar o registo selecionado. Contacte o programador");
        }

        //lista de vinhos temporária
        let vinhos = Store.getAllFromLocalStorage()

        //percorre o indice da nossa lista de vinho
        for(let vinho in vinhos) {

            //valida se o index é o mesmo
            if(parseInt(vinho) === rowIndex -1) {

                //salva o id na localstorage
                Store.updateFlag('userSelectedId', vinhos[vinho].ID);

                //mostra a modal
                document.getElementById('modal').style.display = "block";
            }
        }
    }

    /**
     * Fecha todas as janelas modais
     */
    static closeModals() {

        //obtém os elementos do html
        const modal = document.getElementById("modal");
        const formModal = document.querySelector("#formModal");

        //esconde as modais
        modal.style.display = "none";

        //esconde a modal das opções de remover ou editar
        formModal.style.display = "none";
    }
}

/**
 * Classe que irá interagir com a local storage
 */
class Store {
    /**
     * Busca todos os registos da local storage
     */
    static getAllFromLocalStorage() {
        //variável da lista
        let listVinhos;

        //valida se tem registos na localStorage
        if(localStorage.getItem('vinhos') == null) {

            //caso não tenha registo cria um array vazio
            listVinhos = [];
        } else {

            //caso tenha registos obtém a lista e converte para o formato JSON
            listVinhos = JSON.parse(localStorage.getItem('vinhos'));
        }

        //retorna a lista
        return listVinhos;
    }

    /**
     * Função que  adiciona ou edita valores
     * de uma flag na localstorage
     * @param {flag desejada} flag
     * @param {valor da flag} value
     */
    static updateFlag(flag, value) {
        return localStorage.setItem(flag, value);   //retorna a flag modificada com os valores dos parametros
    }
}

class BD {
    static getAllRegioesFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Regiao/getAllRegioes.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const regioes = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //obtém o tbody da tabela do vinho através do ID
                let regiaoSelect = document.querySelector('#regiao');

                //retorna a lista da base de dados
                regioes.result.forEach((regiao) => {
                    var opt = document.createElement('option');
                    opt.value = regiao.ID;
                    opt.innerHTML = regiao.Denominacao;
                    regiaoSelect.appendChild(opt);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('regioes', JSON.stringify(regioes.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getALLEdicoesFromDatabase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Edicao/getAllEdicoes.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const edicoes = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('edicoes', JSON.stringify(edicoes.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getALLPremiosFromDatabase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Premio/getAllPremios.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const premios = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('premios', JSON.stringify(premios.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getALLGanhosFromDatabase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Ganha/getAllGanhos.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const ganhos = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('ganhos', JSON.stringify(ganhos.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllVinhosFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Vinho/getAllVinhos.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const vinhos = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {

                //retorna a lista da base de dados
                vinhos.result.forEach((vinho) => {
                    UI.addVinhoToTable(vinho);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('vinhos', JSON.stringify(vinhos.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllVinhosFilteredFromDataBase (filtersMap) {
        let parametros = '';

        filtersMap.forEach(function(value, key) {
            parametros += key + "=" + value + "&";
        });

        parametros = parametros.substring(0, parametros.length - 1);

        if(filtersMap.size > 1) {
            parametros += "&logic" + "=" + document.querySelector('#logicSelect').value;
        }

        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Vinho/getAllVinhosFiltered.php?' + parametros ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const vinhos = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {

                //retorna a lista da base de dados
                vinhos.result.forEach((vinho) => {
                    UI.addVinhoToTable(vinho);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                Store.updateFlag('vinhos', JSON.stringify(vinhos.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }
}

///////////////////////////////////////////////////////////////
/// Evento para adicionar quando DOM for carregado
///////////////////////////////////////////////////////////////

document.addEventListener('DOMContentLoaded', UI.getAll);

///////////////////////////////////////////////////////////////
/// Evento para remover quando haver clique do botão
///////////////////////////////////////////////////////////////
/**
 * Click event when click
 */
document.getElementById('vinhoList').addEventListener('click', function (e) {
    e.preventDefault();
    //removing row element from the table
    UI.clickForAction(e.target);
});

document.querySelector('.clear').addEventListener('click', () =>{
    filterCount = 0;
    document.querySelector('#filterCount').innerHTML = "Filtros: " + filterCount;
    filtersMap.clear();
});

document.querySelector('.add').addEventListener('click', () =>{
    let filter = document.querySelector('#filterSelect').value;
    let value = document.querySelector('#filterInput').value;

    if(filter === "Regiao") {
        value = document.querySelector('#regiao').value;
    }

    filterCount++;
    document.querySelector('#filterCount').innerHTML = "Filtros: " + filterCount;
    filtersMap.set(filter, value);
});

document.querySelector('.search').addEventListener('click', () =>{
    UI.removeAllTableRows();

    BD.getAllVinhosFilteredFromDataBase(filtersMap);

    filterCount = 0;
    document.querySelector('#filterCount').innerHTML = "Filtros: " + filterCount;
    filtersMap.clear();
});

function checkRegiao(e) {
    if(e.target.value === "Regiao") {
        document.querySelector('#inputDiv').style["display"] = "none";
        document.querySelector('#regiaoDiv').style["display"] = "inline-block";
    } else {
        document.querySelector('#inputDiv').style["display"] = "inline-block";
        document.querySelector('#regiaoDiv').style["display"] = "none";
    }
}

/*---------------------------------MODAL------------------------------------------------*/

// obtém a modal
var modal = document.getElementById("modal");

/*Faz a modal fechar com clique no X*/
document.querySelector('.close').addEventListener('click', ()=> {
    UI.closeModals();
});

// quando utilizador clicar qualquer lugar fora da modal, a modal fecha-se
window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
}