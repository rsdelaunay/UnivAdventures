/**
 * This class will handle all actions
 * about graphic actions
 */
class UI {
    /**
     * Preeenche o formulário da modal para editar dados
     */
    static fillEditForm() {
        //obtém os elementos do form na modal
        const nome = document.querySelector('#nome');
        const dataEngarrafamento = document.querySelector('#dataEngarrafamento');
        const teorAlcoolico = document.querySelector('#teorAlcoolico');
        const tipo = document.querySelector('#tipo');
        const cor = document.querySelector('#cor');
        const aroma = document.querySelector('#aroma');
        const sabor = document.querySelector('#sabor');
        const regiao = document.querySelector('#regiao');

        const nomeVinicola = document.querySelector('#nomeVinicola');
        const email = document.querySelector('#email');
        const morada = document.querySelector('#morada');
        const codigoPostal = document.querySelector('#codigoPostal');
        const telefone = document.querySelector('#telefone');

        //obtém o item
        let userIdFromLocalStorage = localStorage.getItem('userSelectedId');
        //lista de vinhos temporária
        let vinhos = Store.getAllFromLocalStorage();

        //percorre o array da local storage
        //vai a procura do valor que temos guardado na key id
        vinhos.forEach((vinho) => {

            //caso encontre o Id do utilizador
            if (parseInt(vinho.ID) === parseInt(userIdFromLocalStorage)) {
                //atribuição de valores aos atributos
                nome.value = vinho.Nome;
                dataEngarrafamento.value = vinho.DataEngarrafamento;
                teorAlcoolico.value = vinho.TeorAlcoolico;
                tipo.value = vinho.Tipo;
                cor.value = vinho.Cor;
                aroma.value = vinho.Aroma;
                sabor.value = vinho.Sabor;
                regiao.value = vinho.Denominacao;

                let produtor = Store.getProdutorFromLocalStorage(vinho.PRODUTOR_ID);

                nomeVinicola.value = produtor.NomeVinicola;
                email.value = produtor.Email;
                morada.value = produtor.Morada;
                codigoPostal.value = produtor.CodigoPostal;
                telefone.value = produtor.Telefone;

                Store.getPremiosGanhosFromLocalStorage(vinho.ID);
            }
        });
    }

    static addPremioToTable(premio) {

        //obtém o tbody da tabela do vinho através do ID
        let list = document.querySelector('#premiosGanhosList');

        //create element - Função que permite criar uma instância do elemento
        //passado no parâmetro de entrada
        const row = document.createElement('tr');

        //construção da lista dentro da tag tbody
        row.innerHTML = `
            <td>${premio.NomeDistincao}</td>            
            <td>${premio.Entidade}</td>
        `;

        //adiciona o elemento filho ao elemento pai que
        //foi criado anteriormente (tr)
        list.appendChild(row);
    }
}

/**
 * Classe que irá interagir com a local storage
 */
class Store {
    /**
     * Busca todos os registos da local storage
     */
    static getAllFromLocalStorage() {
        //variável da lista
        let listVinhos = [];

        //valida se tem registos na localStorage
        if(localStorage.getItem('vinhos') != null) {
            //caso tenha registos obtém a lista e converte para o formato JSON
            listVinhos = JSON.parse(localStorage.getItem('vinhos'));
        }

        //retorna a lista
        return listVinhos;
    }

    static getEdicoesFromLocalStorage(vinhoId) {
        let vinhoID = vinhoId;

        return JSON.parse(localStorage.getItem('edicoes')).filter((element) => element.VinhoID === vinhoID);
    }

    static getPremiosFromLocalStorage() {
        //variável da lista
        let listPremios = [];

        //valida se tem registos na localStorage
        if(localStorage.getItem('premios') != null) {
            //caso tenha registos obtém a lista e converte para o formato JSON
            listPremios = JSON.parse(localStorage.getItem('premios'));
        }

        //retorna a lista
        return listPremios;
    }

    static getGanhosFromLocalStorage(vinhoID) {
        //variável da lista
        let listEdicoes = this.getEdicoesFromLocalStorage(vinhoID);
        let listGanhos = [];

        //valida se tem registos na localStorage
        if(localStorage.getItem('ganhos') != null) {
            JSON.parse(localStorage.getItem('ganhos')).forEach(element => {
                listEdicoes.forEach(edicao => {
                    if(element.EdicaoID === edicao.ID) {
                        listGanhos.push(element);
                    }
                });
            });
        }

        //retorna a lista
        return listGanhos;
    }

    static getPremiosGanhosFromLocalStorage(vinhoID) {
        let listGanhos = this.getGanhosFromLocalStorage(vinhoID);
        let listPremios = this.getPremiosFromLocalStorage();

        listGanhos.forEach(ganho => {
            listPremios.forEach(premio => {
                if(ganho.PremioID === premio.ID) {
                    UI.addPremioToTable(premio);
                }
            });
        });
    }

    static getProdutorFromLocalStorage(produtorId) {
        let produtorID = produtorId;
        return JSON.parse(localStorage.getItem('produtores')).find((element) => element.ID === produtorID);
    }
}

///////////////////////////////////////////////////////////////
/// Evento para adicionar quando DOM for carregado
///////////////////////////////////////////////////////////////

document.addEventListener('DOMContentLoaded', UI.fillEditForm);