/**
 * Class of Colheita
 */
class Colheita {
    /**
     * full constructor
     * @param Id
     * @param AnoColheita
     * @param DataInicioColheita
     * @param ProdutorID
     */
    constructor(Id, AnoColheita, DataInicioColheita, RegiaoID, ProdutorID) {
        this.Id = Id;
        this.AnoColheita = AnoColheita;
        this.DataInicioColheita = DataInicioColheita;
        this.RegiaoID = RegiaoID;
        this.ProdutorID = ProdutorID;
    }
}

/**
 * This class will handle all actions
 * about graphic actions
 */
class UI {
    /**
     * Get all colheitas from local storage (future)
     */
    static getAll() {

        //obtém da base de dados e cria os registos na tabela
        BD.getAllRegioesFromDataBase();
        BD.getAllProdutoresFromDataBase();
    }

    /**
     * Fecha todas as janelas modais
     */
    static closeModals() {

        //obtém os elementos do html
        const formModal = document.querySelector("#formModal");

        //esconde a modal das opções de remover ou editar
        formModal.style.display = "none";
    }

    /**
     * Limpa todos os campos do formulário
     */
    static resetForm() {
        //limpa os dados do formulário
        document.querySelector('#anoColheita').value = '';
        document.querySelector('#dataInicioColheita').value = '';
        document.querySelector('#regiao').value = '';
        document.querySelector('#produtor').value = '';
    }
}

/**
 * this class will handle all actions about local storage
 */
class LocalStorage {
    /**
     * Insere um registo na base de dados
     * @return {Promise<void>}
     */
    static async insertOnDataBase() {

        //#region Obtém os valores do formulário
        //exportar função para devolver objeto com os valores do formulário
        //obtém os elementos do form na modal
        let anoColheita = document.querySelector('#anoColheita').value;
        let dataInicioColheita = document.querySelector('#dataInicioColheita').value;
        let regiao = document.querySelector('#regiao').value;
        let produtor = document.querySelector('#produtor').value;

        //cria novo objeto com os valores que vem do formulário
        const colheita = new Colheita(0, anoColheita, dataInicioColheita, regiao, produtor);

        //parametros para salvar na bd
        let parametros = `AnoColheita=${colheita.AnoColheita}&DataInicioColheita=${colheita.DataInicioColheita}&RegiaoID=${colheita.RegiaoID}&ProdutorID=${colheita.ProdutorID}`;

        //endpoint para isert
        let url = '../Classes/SQL/Colheita/addColheita.php';

        //instancia ajax para comunicação
        let request = new XMLHttpRequest();

        //faz chamada para o nosso endpoint de insert
        request.open('POST', url, true);

        // Envia a informação do cabeçalho junto com a requisição.
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        //ação com sucesso
        request.onload = await function () {
            alert(` Status: ${request.status} \n
                    Response: ${request.responseText}`);
        }

        //ação com erros
        request.onerror = await function () {
            alert(` Status: ${ request.status} \n
                    Response: ${request.responseText}`);
        }

        //envia com os parametros no body ou seja, encripitado
        request.send(parametros);

        //fecha as modais
        UI.closeModals();
    }

    /**
     * Função que  adiciona ou edita valores
     * de uma flag na localstorage
     * @param {flag} flag
     * @param {value} value
     */
    static updateFlag(flag, value) {
        return localStorage.setItem(flag, value);   //retorna a flag modificada com os valores dos parametros
    }
}

class BD {
    static getAllRegioesFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Regiao/getAllRegioes.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const regioes = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //obtém o tbody da tabela do colheita através do ID
                let regiaoSelect = document.querySelector('#regiao');

                //retorna a lista da base de dados
                regioes.result.forEach((regiao) => {
                    var opt = document.createElement('option');
                    opt.value = regiao.ID;
                    opt.innerHTML = regiao.Denominacao;
                    regiaoSelect.appendChild(opt);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                LocalStorage.updateFlag('regioes', JSON.stringify(regioes.result));
            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }

    static getAllProdutoresFromDataBase () {
        //url que desejamos aceder da nossa API
        //endpoint
        let url = '../Classes/SQL/Produtor/getAllProdutores.php' ;

        //instância do XMLHttpRequest -
        let request = new XMLHttpRequest();

        //abre ligação assincrona para a base de dados
        request.open('GET', url, true);

        request.onload =  function () {

            //converte do formato json para acedermos a lista result
            const produtores = JSON.parse(this.responseText);

            //resposta for ok = 200
            if(this.status === 200) {
                //obtém o tbody da tabela do colheita através do ID
                let produtorSelect = document.querySelector('#produtor');

                //retorna a lista da base de dados
                produtores.result.forEach((produtor) => {
                    var opt = document.createElement('option');
                    opt.value = produtor.ID;
                    opt.innerHTML = produtor.NomeVinicola;
                    produtorSelect.appendChild(opt);
                });

                //adiciona localmente na localstorage os 5 primeiros registos da bd
                LocalStorage.updateFlag('produtores', JSON.stringify(produtores.result));

            } else {
                console.warn(`Deu ruim ${this.status}`);
            }
        }

        //efetua o pedido a API
        request.send();
    }
}

////////////////////////////////////////////////////////////////////////////////////
////////////        Events                             ////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

document.addEventListener('DOMContentLoaded', UI.getAll);

/**
 * Botão que irá decidir as ações de:
 * Insert
 * Delete
 * Update
 */
document.querySelector('#formModal').addEventListener('submit', (e) => {

    //impede a página de recarregar
    e.preventDefault();

    //action da local storage
    let action = localStorage.getItem('action');

    //consoante a flag, executa uma determinada ação.
    switch (action) {
        case 'INSERT':

            if (validate()) {
                LocalStorage.updateFlag('action', 'INSERT')
                //chama função para adicionar um registo na local storage
                LocalStorage.insertOnDataBase();

                //limpa o formulário
                UI.resetForm();

                //esconde as janelas modais
                UI.closeModals();
            }
            break;
    }

});
/**
 * Função que orá validar se o formulário está a funcionar corretamente
 */
function validate() {
    //Elementos html
    let anoColheita = document.getElementById("anoColheita");
    let dataInicioColheita = document.getElementById("dataInicioColheita");

    if (validateNumbers(anoColheita.value) && !validateEmpty(anoColheita.value) && !validateEmpty(dataInicioColheita.value)){
        return true;
    } else {
        return false;
    }

}

/************************* Regex e metodos de validação ****************************************** */
let regexForLetters = /^[A-Za-z\u00f8]+/g;
let regexForNumbers = /^[0-9]+$/;

/**
 * Função que valida apenas texto
 * @param inputText texto do formulário
 * @returns {boolean} true é apenas texto /false - não é somente texto
 */
function validateLetters(inputText) {

    //validação com regex para obter somente números texto
    if (inputText.match(regexForLetters) ) {
        return true;
    } else {
        return false;
    }
}


/**
 * Função que valida apenas os números
 * @param inputText texto do formulário
 * @returns {boolean} true é apenas número /false - não é somente número
 */
function validateNumbers(inputNumbers) {
    //validações para os números
    if (inputNumbers.match( regexForNumbers)) {
        return true
    } else {
        return false
    }
}

/**
 * Função que valida se tá vazio
 * @param inputText texto do formulário
 * @returns {boolean} true - vazio / false - preenchido
 */
function validateEmpty(inputText) {

    //valida se está vazio
    if (inputText.length === 0 || typeof inputText.textContent === undefined) {
        return true;
    }
    return false;
}